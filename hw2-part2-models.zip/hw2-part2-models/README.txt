Answers from the COMP 440 HW2 Colab notebook, models "base", "sft-succinct", "sft-persona", "succinct", "persona".

responses/*.jsonl   one line per test item: id, model, response, raw, new_tokens,
    max_new_tokens, hit_limit
models.json   what the models are, for init-run's --models-json
generation-notes.txt   how the answers were made, for init-run's --generation-notes

To make a run from this folder, run this from the repository's folder, with FOLDER the path
to this folder:

python3 evals/shared/grade_tools.py init-run --root evals/runs --name SLUG \
    --title "..." --description "..." --items evals/shared evals/mine \
    --responses FOLDER/responses/*.jsonl --models-json FOLDER/models.json \
    --generation-notes "$(cat FOLDER/generation-notes.txt)"
